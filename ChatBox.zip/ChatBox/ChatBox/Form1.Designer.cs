﻿namespace ChatBox
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.title = new System.Windows.Forms.Label();
            this.btn_regenerate = new System.Windows.Forms.Button();
            this.txt_risultato = new System.Windows.Forms.TextBox();
            this.btn_invio = new System.Windows.Forms.Button();
            this.btn_cambia_sfondo = new System.Windows.Forms.Button();
            this.rb_articolato = new System.Windows.Forms.RadioButton();
            this.rb_semplice = new System.Windows.Forms.RadioButton();
            this.btn_genera = new System.Windows.Forms.Button();
            this.txt_parole_chiave = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_messaggio = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_limite = new System.Windows.Forms.TextBox();
            this.txt_contesto = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Chat = new System.Windows.Forms.GroupBox();
            this.TBLP1 = new System.Windows.Forms.TableLayoutPanel();
            this.btn_clear = new System.Windows.Forms.Button();
            this.btn_clear_wallpaper = new System.Windows.Forms.Button();
            this.btn_PowerOff = new System.Windows.Forms.Button();
            this.btn_reduceTOIcon = new System.Windows.Forms.Button();
            this.btn_add_chat = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.TBLP_chat = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox1.SuspendLayout();
            this.Chat.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // title
            // 
            this.title.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.title.AutoSize = true;
            this.title.BackColor = System.Drawing.Color.Transparent;
            this.title.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.8F);
            this.title.Location = new System.Drawing.Point(231, 67);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(150, 39);
            this.title.TabIndex = 1;
            this.title.Text = "ChatBox";
            // 
            // btn_regenerate
            // 
            this.btn_regenerate.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_regenerate.BackgroundImage")));
            this.btn_regenerate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_regenerate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_regenerate.Location = new System.Drawing.Point(481, 490);
            this.btn_regenerate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_regenerate.Name = "btn_regenerate";
            this.btn_regenerate.Size = new System.Drawing.Size(55, 47);
            this.btn_regenerate.TabIndex = 21;
            this.btn_regenerate.UseVisualStyleBackColor = true;
            this.btn_regenerate.Click += new System.EventHandler(this.btn_regenerate_Click);
            // 
            // txt_risultato
            // 
            this.txt_risultato.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.8F);
            this.txt_risultato.Location = new System.Drawing.Point(84, 490);
            this.txt_risultato.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_risultato.Multiline = true;
            this.txt_risultato.Name = "txt_risultato";
            this.txt_risultato.Size = new System.Drawing.Size(391, 98);
            this.txt_risultato.TabIndex = 27;
            this.txt_risultato.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_risultato_KeyDown_1);
            // 
            // btn_invio
            // 
            this.btn_invio.BackColor = System.Drawing.Color.Transparent;
            this.btn_invio.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_invio.BackgroundImage")));
            this.btn_invio.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_invio.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_invio.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.btn_invio.Location = new System.Drawing.Point(481, 542);
            this.btn_invio.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_invio.Name = "btn_invio";
            this.btn_invio.Size = new System.Drawing.Size(56, 47);
            this.btn_invio.TabIndex = 28;
            this.btn_invio.UseVisualStyleBackColor = false;
            this.btn_invio.Click += new System.EventHandler(this.btn_invio_Click);
            // 
            // btn_cambia_sfondo
            // 
            this.btn_cambia_sfondo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_cambia_sfondo.BackgroundImage")));
            this.btn_cambia_sfondo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_cambia_sfondo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_cambia_sfondo.Location = new System.Drawing.Point(13, 643);
            this.btn_cambia_sfondo.Margin = new System.Windows.Forms.Padding(4);
            this.btn_cambia_sfondo.Name = "btn_cambia_sfondo";
            this.btn_cambia_sfondo.Size = new System.Drawing.Size(54, 49);
            this.btn_cambia_sfondo.TabIndex = 31;
            this.btn_cambia_sfondo.UseVisualStyleBackColor = true;
            this.btn_cambia_sfondo.Click += new System.EventHandler(this.btn_cambia_sfondo_Click);
            // 
            // rb_articolato
            // 
            this.rb_articolato.AutoSize = true;
            this.rb_articolato.BackColor = System.Drawing.Color.Transparent;
            this.rb_articolato.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F);
            this.rb_articolato.Location = new System.Drawing.Point(296, 198);
            this.rb_articolato.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rb_articolato.Name = "rb_articolato";
            this.rb_articolato.Size = new System.Drawing.Size(90, 22);
            this.rb_articolato.TabIndex = 43;
            this.rb_articolato.TabStop = true;
            this.rb_articolato.Text = "articolato";
            this.rb_articolato.UseVisualStyleBackColor = false;
            // 
            // rb_semplice
            // 
            this.rb_semplice.AutoSize = true;
            this.rb_semplice.BackColor = System.Drawing.Color.Transparent;
            this.rb_semplice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F);
            this.rb_semplice.Location = new System.Drawing.Point(182, 198);
            this.rb_semplice.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rb_semplice.Name = "rb_semplice";
            this.rb_semplice.Size = new System.Drawing.Size(88, 22);
            this.rb_semplice.TabIndex = 42;
            this.rb_semplice.TabStop = true;
            this.rb_semplice.Text = "semplice";
            this.rb_semplice.UseVisualStyleBackColor = false;
            // 
            // btn_genera
            // 
            this.btn_genera.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_genera.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.8F);
            this.btn_genera.Location = new System.Drawing.Point(151, 253);
            this.btn_genera.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_genera.Name = "btn_genera";
            this.btn_genera.Size = new System.Drawing.Size(144, 39);
            this.btn_genera.TabIndex = 41;
            this.btn_genera.Text = "GENERA";
            this.btn_genera.UseVisualStyleBackColor = true;
            this.btn_genera.Click += new System.EventHandler(this.btn_genera_Click_1);
            // 
            // txt_parole_chiave
            // 
            this.txt_parole_chiave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F);
            this.txt_parole_chiave.Location = new System.Drawing.Point(226, 95);
            this.txt_parole_chiave.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_parole_chiave.Name = "txt_parole_chiave";
            this.txt_parole_chiave.Size = new System.Drawing.Size(136, 24);
            this.txt_parole_chiave.TabIndex = 40;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F);
            this.label7.Location = new System.Drawing.Point(110, 202);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(34, 18);
            this.label7.TabIndex = 39;
            this.label7.Text = "stile";
            // 
            // txt_messaggio
            // 
            this.txt_messaggio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F);
            this.txt_messaggio.Location = new System.Drawing.Point(124, 44);
            this.txt_messaggio.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_messaggio.Name = "txt_messaggio";
            this.txt_messaggio.Size = new System.Drawing.Size(361, 24);
            this.txt_messaggio.TabIndex = 38;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F);
            this.label5.Location = new System.Drawing.Point(35, 47);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 18);
            this.label5.TabIndex = 37;
            this.label5.Text = "Messaggio ";
            // 
            // txt_limite
            // 
            this.txt_limite.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F);
            this.txt_limite.Location = new System.Drawing.Point(226, 154);
            this.txt_limite.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_limite.Name = "txt_limite";
            this.txt_limite.Size = new System.Drawing.Size(136, 24);
            this.txt_limite.TabIndex = 36;
            // 
            // txt_contesto
            // 
            this.txt_contesto.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_contesto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F);
            this.txt_contesto.Location = new System.Drawing.Point(226, 124);
            this.txt_contesto.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_contesto.Name = "txt_contesto";
            this.txt_contesto.Size = new System.Drawing.Size(136, 24);
            this.txt_contesto.TabIndex = 35;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F);
            this.label6.Location = new System.Drawing.Point(97, 103);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 18);
            this.label6.TabIndex = 34;
            this.label6.Text = "destinatario";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F);
            this.label3.Location = new System.Drawing.Point(97, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 18);
            this.label3.TabIndex = 33;
            this.label3.Text = "contesto";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F);
            this.label2.Location = new System.Drawing.Point(97, 160);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 18);
            this.label2.TabIndex = 32;
            this.label2.Text = "limite parole";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.rb_articolato);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.rb_semplice);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.btn_genera);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txt_parole_chiave);
            this.groupBox1.Controls.Add(this.txt_contesto);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txt_limite);
            this.groupBox1.Controls.Add(this.txt_messaggio);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(51, 133);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(503, 321);
            this.groupBox1.TabIndex = 44;
            this.groupBox1.TabStop = false;
            // 
            // Chat
            // 
            this.Chat.BackColor = System.Drawing.Color.Transparent;
            this.Chat.Controls.Add(this.TBLP1);
            this.Chat.Location = new System.Drawing.Point(721, 67);
            this.Chat.Margin = new System.Windows.Forms.Padding(4);
            this.Chat.Name = "Chat";
            this.Chat.Padding = new System.Windows.Forms.Padding(4);
            this.Chat.Size = new System.Drawing.Size(788, 611);
            this.Chat.TabIndex = 45;
            this.Chat.TabStop = false;
            this.Chat.Text = "CHAT";
            // 
            // TBLP1
            // 
            this.TBLP1.ColumnCount = 3;
            this.TBLP1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 67.80684F));
            this.TBLP1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 361F));
            this.TBLP1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.TBLP1.Location = new System.Drawing.Point(8, 23);
            this.TBLP1.Margin = new System.Windows.Forms.Padding(4);
            this.TBLP1.Name = "TBLP1";
            this.TBLP1.RowCount = 2;
            this.TBLP1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.TBLP1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 71F));
            this.TBLP1.Size = new System.Drawing.Size(772, 580);
            this.TBLP1.TabIndex = 0;
            // 
            // btn_clear
            // 
            this.btn_clear.BackColor = System.Drawing.Color.Transparent;
            this.btn_clear.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_clear.BackgroundImage")));
            this.btn_clear.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.btn_clear.Location = new System.Drawing.Point(647, 619);
            this.btn_clear.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(56, 47);
            this.btn_clear.TabIndex = 46;
            this.btn_clear.UseVisualStyleBackColor = false;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // btn_clear_wallpaper
            // 
            this.btn_clear_wallpaper.BackColor = System.Drawing.Color.Transparent;
            this.btn_clear_wallpaper.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_clear_wallpaper.BackgroundImage")));
            this.btn_clear_wallpaper.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_clear_wallpaper.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_clear_wallpaper.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.btn_clear_wallpaper.Location = new System.Drawing.Point(74, 643);
            this.btn_clear_wallpaper.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_clear_wallpaper.Name = "btn_clear_wallpaper";
            this.btn_clear_wallpaper.Size = new System.Drawing.Size(56, 51);
            this.btn_clear_wallpaper.TabIndex = 47;
            this.btn_clear_wallpaper.UseVisualStyleBackColor = false;
            this.btn_clear_wallpaper.Click += new System.EventHandler(this.btn_clear_wallpaper_Click);
            // 
            // btn_PowerOff
            // 
            this.btn_PowerOff.BackColor = System.Drawing.Color.Red;
            this.btn_PowerOff.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_PowerOff.BackgroundImage")));
            this.btn_PowerOff.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_PowerOff.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_PowerOff.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.btn_PowerOff.Location = new System.Drawing.Point(1507, 11);
            this.btn_PowerOff.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_PowerOff.Name = "btn_PowerOff";
            this.btn_PowerOff.Size = new System.Drawing.Size(40, 35);
            this.btn_PowerOff.TabIndex = 48;
            this.btn_PowerOff.UseVisualStyleBackColor = false;
            this.btn_PowerOff.Click += new System.EventHandler(this.btn_PowerOff_Click);
            // 
            // btn_reduceTOIcon
            // 
            this.btn_reduceTOIcon.BackColor = System.Drawing.Color.Red;
            this.btn_reduceTOIcon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_reduceTOIcon.BackgroundImage")));
            this.btn_reduceTOIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_reduceTOIcon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_reduceTOIcon.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.btn_reduceTOIcon.Location = new System.Drawing.Point(1461, 11);
            this.btn_reduceTOIcon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_reduceTOIcon.Name = "btn_reduceTOIcon";
            this.btn_reduceTOIcon.Size = new System.Drawing.Size(40, 35);
            this.btn_reduceTOIcon.TabIndex = 49;
            this.btn_reduceTOIcon.UseVisualStyleBackColor = false;
            this.btn_reduceTOIcon.Click += new System.EventHandler(this.btn_reduceTOIcon_Click);
            // 
            // btn_add_chat
            // 
            this.btn_add_chat.BackColor = System.Drawing.Color.Transparent;
            this.btn_add_chat.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_add_chat.BackgroundImage")));
            this.btn_add_chat.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_add_chat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_add_chat.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.btn_add_chat.Location = new System.Drawing.Point(618, 77);
            this.btn_add_chat.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_add_chat.Name = "btn_add_chat";
            this.btn_add_chat.Size = new System.Drawing.Size(56, 51);
            this.btn_add_chat.TabIndex = 50;
            this.btn_add_chat.UseVisualStyleBackColor = false;
            this.btn_add_chat.Click += new System.EventHandler(this.btn_add_chat_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.TBLP_chat);
            this.groupBox2.Location = new System.Drawing.Point(592, 133);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(111, 472);
            this.groupBox2.TabIndex = 51;
            this.groupBox2.TabStop = false;
            // 
            // TBLP_chat
            // 
            this.TBLP_chat.ColumnCount = 1;
            this.TBLP_chat.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TBLP_chat.Location = new System.Drawing.Point(6, 11);
            this.TBLP_chat.Name = "TBLP_chat";
            this.TBLP_chat.RowCount = 10;
            this.TBLP_chat.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.TBLP_chat.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.TBLP_chat.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.TBLP_chat.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.TBLP_chat.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.TBLP_chat.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.TBLP_chat.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.TBLP_chat.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.TBLP_chat.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.TBLP_chat.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.TBLP_chat.Size = new System.Drawing.Size(105, 455);
            this.TBLP_chat.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(1550, 705);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btn_add_chat);
            this.Controls.Add(this.btn_reduceTOIcon);
            this.Controls.Add(this.btn_PowerOff);
            this.Controls.Add(this.btn_clear_wallpaper);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.Chat);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btn_cambia_sfondo);
            this.Controls.Add(this.btn_invio);
            this.Controls.Add(this.title);
            this.Controls.Add(this.txt_risultato);
            this.Controls.Add(this.btn_regenerate);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ChatBox";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.Chat.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Button btn_regenerate;
        private System.Windows.Forms.TextBox txt_risultato;
        private System.Windows.Forms.Button btn_invio;
        private System.Windows.Forms.Button btn_cambia_sfondo;
        private System.Windows.Forms.RadioButton rb_articolato;
        private System.Windows.Forms.RadioButton rb_semplice;
        private System.Windows.Forms.Button btn_genera;
        private System.Windows.Forms.TextBox txt_parole_chiave;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_messaggio;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_limite;
        private System.Windows.Forms.TextBox txt_contesto;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox Chat;
        private System.Windows.Forms.TableLayoutPanel TBLP1;
        private System.Windows.Forms.VScrollBar vScrollBar1;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button btn_clear_wallpaper;
        private System.Windows.Forms.Button btn_PowerOff;
        private System.Windows.Forms.Button btn_reduceTOIcon;
        private System.Windows.Forms.Button btn_add_chat;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TableLayoutPanel TBLP_chat;
    }
}

