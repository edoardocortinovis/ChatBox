﻿using System;
using System.Windows.Forms;

namespace ChatBox
{
    internal class parametri
    {
        private string _messaggio;
        public string messaggio
        {
            get { return _messaggio; }
            set
            {
                if (string.IsNullOrEmpty(value) == true)
                {
                    throw new Exception("Errore");
                }
                _messaggio = value;
            }
        }

        private string _parolachiave;
        public string parolachiave
        {
            get { return _parolachiave; }
            set
            {
                if (string.IsNullOrEmpty(value) == true)
                {
                    throw new Exception("Errore");
                }
                _parolachiave = value;
            }
        }

        private string _contesto;
        public string contesto
        {
            get { return _contesto; }
            set
            {
                if (string.IsNullOrEmpty(value) == true)
                {
                    throw new Exception("Errore");
                }
                _contesto = value;
            }
        }

        private int _max;
        public int max
        {
            get { return _max; }
            set
            {
                if (string.IsNullOrEmpty(value.ToString()) == true && value > 50)
                {
                    MessageBox.Show("Il massimo delle parole è di 50");
                }
                _max = value;
            }
        }

        private string _stile;
        public string stile
        {
            get { return _stile; }
            set { _stile = value; }
        }

        public parametri(string messaggio, string contesto, int max, string stile, string parolachiave)
        {
            this.messaggio = messaggio;
            this.contesto = contesto;
            this.max = max;
            this.stile = stile;
            this.parolachiave = parolachiave;
        }

        public override string ToString()
        {
            return $"{this.messaggio} - {this.contesto} - {this.max} - {this.stile} - {this.parolachiave}";
        }
    }
}
