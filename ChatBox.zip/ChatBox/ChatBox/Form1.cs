﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace ChatBox
{
    public partial class Form1 : Form
    {

        private readonly HttpClient httpClient;
        private string OpenAIApiKey = "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"; /*KEY api*/
        private string GptChatEndpoint = "https://api.openai.com/v1/chat/completions"; /*END-POINT per richiamare api*/

        public Form1()
        {
            InitializeComponent();

            httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {OpenAIApiKey}");

            //SCOLL-BAR
            vScrollBar1 = new VScrollBar();
            Controls.Add(vScrollBar1);

            //PRIMO AZZERAMENTO DEL TABLE LAYOUT PANEL COSI CHE NON SI CREI LO SPAZIO INIZIALE TRA I PRIMI 2 MESSAGGI
            TBLP1.Controls.Clear();
            TBLP1.RowStyles.Clear();
        }

        #region FINESTRA
        private void btn_reduceTOIcon_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btn_PowerOff_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion

        #region MESSAGGIO

        //lista parametri solita
        static List<parametri> eleParametri = new List<parametri>();


        private async void btn_genera_Click_1(object sender, EventArgs e)
        {
            parametri NuoviParametri = default;

            string messaggio = txt_messaggio.Text;
            string contesto = txt_contesto.Text;
            int limite = int.Parse(txt_limite.Text);

            string stile = "";
            if (rb_articolato.Checked)
            {
                stile = "stile articolato";
            }
            else if (rb_semplice.Checked)
            {
                stile = "stile semplice";
            }

            string parolachiave = txt_parole_chiave.Text;

            //richiamo costruttore
            NuoviParametri = new parametri(messaggio, contesto, limite, stile, parolachiave);

            //aggiungo parametri alla lista
            eleParametri.Add(NuoviParametri);

            /*--------------------------------------------------------------------------RISPOSTA----------------------------------------------------------------------------------*/
            string responseContent = await GeneraMessaggio(NuoviParametri);

            //richiamo il metodo che estre la risposta
            txt_risultato.Text = responseContent;
        }

        //CODICE NODE TRADOTTO IN C# PRESO DALLA DOCUMENTAZIONE DI OPENAI
        private async Task<string> GeneraMessaggio(parametri parametri)
        {
            //request all api con i nostri parametri salvati
            string messaggio = $"{parametri.messaggio} Fornito questo messaggio, riscrivilo con uno stile {parametri.stile}, " +
                                $"un massimo di {parametri.max} parole e un contesto {parametri.contesto}, e inserisci oppure fai capire il destinatario: " +
                                $"{parametri.parolachiave} all'interno del messaggio";

            //richiestaa con specifica di modello e il content (cosi richiede OPEN-AI)
            var requestData = new
            {
                messages = new[] { new { role = "system", content = messaggio } },
                model = "gpt-3.5-turbo"
            };

            //RISPOSTA CON LA SERIALIZZAZIONE
            var content = new StringContent(Newtonsoft.Json.JsonConvert.SerializeObject(requestData), Encoding.UTF8, "application/json");
            var response = await httpClient.PostAsync(GptChatEndpoint, content);

            if (response.IsSuccessStatusCode)
            {
                string jsonResponse = await response.Content.ReadAsStringAsync();
                JObject jsonObject = JObject.Parse(jsonResponse);
                //estrazione della risposta dal file json restituito dall'api
                string risultato = (string)jsonObject["choices"][0]["message"]["content"];
                return risultato;
            }
            else
            {
                return "Errore API";
            }
        }

        //MESSAGGIO RIGENERATO
        private async void btn_regenerate_Click(object sender, EventArgs e)
        {
            //controllo che i parametri nn siano stati eliminati x la rigenerazioni
            if (eleParametri.Count > 0)
            {
                txt_risultato.Clear();

                //Prendo gli ultimi dati salvati per rigenerare il messaggio
                parametri ultimiParametri = eleParametri.FirstOrDefault();
                string responseContent = await GeneraMessaggio(ultimiParametri);
                txt_risultato.Text = responseContent;
            }
            else
            {
                MessageBox.Show("Compila i campi per rigenerare il messaggio");
            }
        }
        #endregion

        #region SFONDO
        private void btn_cambia_sfondo_Click(object sender, EventArgs e)
        {
            //https://learn.microsoft.com/it-it/dotnet/api/system.windows.forms.openfiledialog?view=windowsdesktop-8.0
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
                openFileDialog.Filter = "File immagine|*.jpg;*.jpeg;*.png;*.gif;*.bmp|Tutti i file|*.*";
                openFileDialog.FilterIndex = 1;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = openFileDialog.FileName;

                    this.BackgroundImage = Image.FromFile(filePath);
                    this.BackgroundImageLayout = ImageLayout.Stretch; //Adatta x fare il background
                }
            }
        }

        //Rimozione wallpaper
        private void btn_clear_wallpaper_Click(object sender, EventArgs e)
        {
            this.BackgroundImage = null;
        }
        #endregion


        //------------------------------------------------------PARTE DELLA CHAT CON IL BOT----------------------------------------------------------------

        //premere invio anziche schiacciare bottone
        private void txt_risultato_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Attiva il click del pulsante btn_invio
                btn_invio.PerformClick();
            }
        }

        #region CHAT CON IL BOT

        //codice identico al precedente senza pero il messaggio come richiesta, quindi uso una funzione diversa
        private async Task<string> RispostaAPI(string userInput)
        {
            var requestData = new
            {
                messages = new[] { new { role = "user", content = userInput } },
                model = "gpt-3.5-turbo"
            };

            var content = new StringContent(Newtonsoft.Json.JsonConvert.SerializeObject(requestData), Encoding.UTF8, "application/json");
            var response = await httpClient.PostAsync(GptChatEndpoint, content);

            if (response.IsSuccessStatusCode)
            {
                string jsonResponse = await response.Content.ReadAsStringAsync();
                JObject jsonObject = JObject.Parse(jsonResponse);
                string sars = (string)jsonObject["choices"][0]["message"]["content"];
                return sars;
            }
            else
            {
                return "Errore API di ChatGPT";
            }
        }

        //LISTA CON ALL'INTERNO LE CHAT che contentgono un indice che possa far riconoscere in che chat si trovano //ex. chatmessages[0] vuole dire che stiamo parlando della prima chat

        //abbiamo infatti una lista con allinterno un altra lista di stringe
        //la prima lista sta per le chat e la seconda per i messaggi
        private List<List<string>> chatMessages = new List<List<string>>();

        int numChat = 0;

        private void btn_add_chat_Click(object sender, EventArgs e)
        {
            //massimo 10 chat
            if (numChat < 10)
            {
                Button bottone = new Button();
                bottone.Text = "CHAT:" + (numChat + 1);
                bottone.Dock = DockStyle.Fill; //si adatta alla grandezza della riga e riempie lo spazio
                bottone.Tag = numChat; //indice per capire che chat sia
                bottone.Click += ChatButton_Click; //gli associo evento click
                TBLP_chat.Controls.Add(bottone, 0, numChat); //aggiungo il bottone alla TBLP_chat

                numChat++;

                //qui aggiungo alla prima lista di stringhe
                chatMessages.Add(new List<string>());
            }
            else
            {
                MessageBox.Show("Hai raggiunto il limite massimo di chat.");
            }
        }

        #region INDICE CHAT

        private int ChatAttuale = -1; // a -1 per indicare che nessuna chat è selezionata,non 0 perchè si inizia a contare da 0, si incrementera poi quando schiaccero sul bottone
        private Button BottoneSchiacciato = null; //variabile a null, perche quando avvio programma nessun bottone è schiacciato
        private void ChatButton_Click(object sender, EventArgs e)
        {
            //trasformiamo l'oggetto sender, ovvero colui che ha scatenato l'evento con un bottone
            Button button = sender as Button;
            ChatAttuale = (int)button.Tag; // Si recupera l'indice della chat corrente associato al bottone
            SwitchChat(ChatAttuale); // Cambia la chat alla corrente

            #region COLORE BOTTONE
            // Cambia il colore di sfondo del bottone selezionato
            if (BottoneSchiacciato != null)
            {
                BottoneSchiacciato.BackColor = Color.Transparent; // Ripristina il colore trasparente per il bottone precedente, se presente
            }
            button.BackColor = Color.GreenYellow; // Imposta il colore selezionato per il bottone schiacciato
            BottoneSchiacciato = button; // Aggiorna il riferimento al bottone selezionato
            #endregion

        }

        private bool ChatSchiacciata = false;
        private void SwitchChat(int chatIndex)
        {
            TBLP1.AutoScroll = false; //toglo autoscroll x farlo arrivare all'ultimo messaggio
            vScrollBar1.Enabled = false;
            vScrollBar1.Visible = false; //disabilito Scrollbar

            //ripulisco chat
            TBLP1.Controls.Clear();
            TBLP1.RowStyles.Clear();
            TBLP1.RowCount = 1;

            LoadChatFromFile(chatIndex); // Carica i messaggi della chat con quell'indice
            ChatSchiacciata = true; //metto a true la booleana per capire se sono sulla chat
        }
        #endregion


        #region CARICA
        //RIESCO A CAPIRE SE PARLA UTENTE O CHAT GPT PERCHE IL MESSAGGIO DELL UTENTE INIZIA CON UTENTE:
        //PERCIO SE INIZIA CON UTENTE: è L'UTENTE SE INIZIA CON ALTRO è IL BOT E COSI LUI RICONOSCE CHI HA SCRITTO
        private void LoadChatFromFile(int chatIndex)
        {
            /*string fileName = $"chat_messages_{chatIndex}.txt"; // Genera il nome del file basato sull'indice della chat
            if (File.Exists(fileName))
            {
                using (StreamReader reader = new StreamReader(fileName))
                {
                    chatMessages[chatIndex].Clear(); //pulisco sia la lista messaggi che la chat

                    string line; //serve per leggere riga per riga
                    while ((line = reader.ReadLine()) != null) //LEGGE OGNI RIGA DEL FILE FINO A CHE NN FINISCONO
                    {
                        if (string.IsNullOrWhiteSpace(line) == false)
                        {
                            CreateChat(line, line.StartsWith("Utente:")); // Crea un messaggio nella chat corrente
                            chatMessages[chatIndex].Add(line); //Questa riga aggiunge la riga letta dalla chat corrente alla lista dei messaggi della chat corrente.
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show($"Il file di chat {chatIndex + 1} non esiste.");
            }*/

            string fileName = $"chat_messages_{chatIndex}.txt"; // Genera il nome del file basato sull'indice della chat
            if (File.Exists(fileName))
            {
                using (StreamReader reader = new StreamReader(fileName))
                {
                    chatMessages[chatIndex].Clear(); // Pulisco la lista dei messaggi

                    string line; // Serve per leggere riga per riga
                    string currentMessage = null; // Mantiene il messaggio corrente
                    bool isUserMessage = false; // Indica se il messaggio corrente è dell'utente
                    while ((line = reader.ReadLine()) != null) // Legge ogni riga del file finché non finiscono
                    {
                        //CONTROLLO SE LA RIGA è VUOTA
                        if (string.IsNullOrWhiteSpace(line) == false)
                        {
                            //CONTROLLO SE L'INIZIO DELLA RIGA è UTENTE O CHATGPT
                            if (line.StartsWith("Utente:") || line.StartsWith("ChatGPT:")) // Nuovo messaggio inizia
                            {
                                if (currentMessage != null)//controlla se ci sono spazi vuoti/righe vuote/messaggi vuoti e nn li aggiugne
                                {
                                    //aggiunge il messaggio alla chat e controlla se il messaggio è dell'utente o di chat gpt con una booelana ISuserMessage
                                    CreateChat(currentMessage, isUserMessage);
                                    chatMessages[chatIndex].Add(currentMessage);//aggiugne messaggio alla lista chat messsageds allindice della chat in cui siamo
                                }
                                isUserMessage = line.StartsWith("Utente:"); // Aggiorna se il nuovo messaggio è dell'utente
                                currentMessage = line;//mette una linea alla fine di ogni messaggio
                            }
                            else
                            // NEL CASO X L'APPUNTO VADA A CAPO E NN INIZI NE CON CHATGPT NE CON UTENTE
                            //VORRA DIRE CHE STIAMO TRATTANDO UN CONTINUO DI UN MESSAGGIO MANDATO A CAPO 
                            //E QUINDI LO AGGIUNGE AL MESSAGGIO CORRENTE
                            {
                                currentMessage += "\n" + line;
                            }
                        }
                    }
                    //QUESTO SERVE PER FAR SI CHE SI SALVI L'ULTIMO MESSAGGIO (RISPOSTA API)
                    //SE NN CI FOSSE NN SI SALVEREBBE PERCHE NN TROVEREBBE UN MESSAGGIO DOPO CON L'INIZIO = AD UTENTE: o finche nn trova fine del file
                    //PERCIO BISOGNA SALVARLO MANUALMENTE
                    if (currentMessage != null) //SALVATAGGIO ULTIMA RISPOSTA API
                    {
                        //aggiunge il messaggio alla chat e controlla se il messaggio è dell'utente o di chat gpt con una booelana ISuserMessage
                        CreateChat(currentMessage, isUserMessage);
                        chatMessages[chatIndex].Add(currentMessage);//aggiugne messaggio alla lista chat messsageds allindice della chat in cui siamo
                    }
                }
            }
            else
            {
                MessageBox.Show($"Il file di chat {chatIndex + 1} non esiste.");
            }
        }
        #endregion

        #region SCRIVI
        private void SaveChatToFile(int chatIndex)
        {
            string fileName = $"chat_messages_{chatIndex}.txt"; // Genera il nome del file basato sull'indice della chat
            using (StreamWriter writer = new StreamWriter(fileName))
            {
                foreach (string item in chatMessages[chatIndex])
                {
                    writer.WriteLine(item);
                }
            }
        }
        #endregion

        private async void btn_invio_Click(object sender, EventArgs e)
        {
            if (ChatSchiacciata == true) //CONTROLLA SE ABBIAMO SELEZIONATO UNA CHAT PRIMA DI INVIARE
            {
                if (string.IsNullOrEmpty(txt_risultato.Text) == false) //CONTROLLA CHE STIAMO INVIANDO UN MESSAGGIO E NON UN MESSAGGIO VUOTO
                {
                    //LE 2 BOOLEANNE SOLO LE VARIABILE ISUSERMESSAGE CHE è TRUE SE è UTENTE E FALSE SE è BOT

                    CreateChat("Utente: " + txt_risultato.Text, true); // Crea un messaggio nella chat corrente
                    chatMessages[ChatAttuale].Add("Utente: " + txt_risultato.Text); // Aggiunge il messaggio alla lista di messaggi ovvero chat messages mentre chat attuale si riferisce all indice della chat

                    string responseContent = await RispostaAPI(txt_risultato.Text);

                    CreateChat("ChatGPT: " + responseContent, false); 
                    chatMessages[ChatAttuale].Add("ChatGPT: " + responseContent); 

                    SaveChatToFile(ChatAttuale); //RICHIAMO FUNZIONA SALVA SU FILE ALLA FINE DI OGNI MESSAGGIO COSI CHE FACCIA UN SALVATAGGIO AUTOMATICO
                }
                else
                {
                    MessageBox.Show("La casella di testo risultato è vuota.");
                }

                TBLP1.AutoScroll = true;
                txt_risultato.Clear();
            }
            else
            {
                MessageBox.Show("Seleziona una chat prima di inviare un messaggio.");
            }
        }

        

        private void CreateChat(string text, bool isUser)
        {
            Label lblMessage = new Label(); //creo label
            lblMessage.AutoSize = true; //per adattarsi al testo
            lblMessage.Text = text; //per mettergli dentro il testo
            lblMessage.Padding = new Padding(5); //padding
            lblMessage.Margin = new Padding(0, 0, 0, 5); //margine
            lblMessage.Font = new Font(lblMessage.Font.FontFamily, 9); //font


            //CONTROLLO SE SCRIVE UTENTE O BOT E CAMBIO COLORE SFONDO
            if (isUser == true)
            {
                lblMessage.BackColor = Color.HotPink;
            }
            else
            {
                lblMessage.BackColor = Color.GreenYellow;
            }

            //RIGHE
            //SE SCRIVE USER AGGIUNGE ALLA COLONNA 0 (SINISTRA)
            //SE SCRIVE BOT AGGIUNGE ALLA COLONNA 1 (DESTRA)
            if (isUser == true)
            {
                TBLP1.Controls.Add(lblMessage, 0, TBLP1.RowCount - 1);
            }
            else
            {
                TBLP1.Controls.Add(lblMessage, 1, TBLP1.RowCount - 1);
            }
            TBLP1.RowCount++;


            UpdateScrollBar();
        }

        //METODO PER SCOLL BAR
        private void UpdateScrollBar()
        {
            /*bisogna dare sia minimo che massimo per calcolare la grandezza del layout panel 
            e far si che io mi possa posizionare in qualsiasi punto della chat senza che crei problemi 

            int NuovoValore = Math.Min(Math.Max(vScrollBar1.Minimum, vScrollBar1.Value), vScrollBar1.Maximum);
            vScrollBar1.Value = NuovoValore;*/

            //è l'autoscroll della chat, ovvero ti fa sempre arrivare all'ultimo messaggio inviato
            TBLP1.AutoScrollPosition = new Point(0, TBLP1.DisplayRectangle.Height);
        }

        //BOTTONE PER PULIRE LA CHAT
        private void btn_clear_Click(object sender, EventArgs e)
        {
            //ripulisco chat
            TBLP1.Controls.Clear();
            TBLP1.RowStyles.Clear();
            //imposo le colonne a 1 perche senno mi da l'errore dello spazio tra primo messaggio e prima risposta
            TBLP1.RowCount = 0;

            //tolgo autoscroll chat e disabilito la scoll bar cosi che ri ripulisca pienamente
            TBLP1.AutoScroll = false;
            vScrollBar1.Enabled = false;
            vScrollBar1.Visible = false;


            //prendo il nome del file
            string fileName = $"chat_messages_{ChatAttuale}.txt";
            //SVUOTO completamente la chat
            File.WriteAllText(fileName, string.Empty);
        }
        #endregion
    }
}